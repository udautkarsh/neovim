return {
	"folke/zen-mode.nvim",
	opts = {},
}
